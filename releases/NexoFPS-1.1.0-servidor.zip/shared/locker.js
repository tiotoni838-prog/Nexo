import { CHARACTERS, CHARACTER_IDS } from './characters.js';
export const emptyLocker = () => ({ owned: [], equipped: {} });
export const isOwned = (locker, sku) => locker.owned.includes(sku);
export const ownItem = (locker, sku) => {
    if (isOwned(locker, sku))
        return locker;
    return { ...locker, owned: [...locker.owned, sku] };
};
export const equipItem = (locker, slot, sku) => {
    if (!isOwned(locker, sku))
        return { locker, error: 'not-owned' };
    return { locker: { ...locker, equipped: { ...locker.equipped, [slot]: sku } } };
};
export const unequipSlot = (locker, slot) => {
    const equipped = { ...locker.equipped };
    delete equipped[slot];
    return { ...locker, equipped };
};
/** Evolutivas: maestría por personaje con umbrales de XP y título por nivel. */
export const MASTERY_XP_THRESHOLDS = [0, 500, 1500, 3000, 5000, 7500, 11000];
export const MASTERY_TITLES_ES = [
    'Novato',
    'Aprendiz',
    'Combatiente',
    'Veterano',
    'Élite',
    'Maestro',
    'Leyenda',
];
export const MASTERY_TITLES_EN = [
    'Rookie',
    'Apprentice',
    'Fighter',
    'Veteran',
    'Elite',
    'Master',
    'Legend',
];
export const masteryLevel = (xp) => {
    let level = 0;
    for (let i = 0; i < MASTERY_XP_THRESHOLDS.length; i++) {
        if (xp >= MASTERY_XP_THRESHOLDS[i])
            level = i;
    }
    return level;
};
export const masteryProgress = (xp) => {
    const level = masteryLevel(xp);
    if (level >= MASTERY_XP_THRESHOLDS.length - 1) {
        return { level, progress: 1, xpToNext: null };
    }
    const current = MASTERY_XP_THRESHOLDS[level];
    const next = MASTERY_XP_THRESHOLDS[level + 1];
    return {
        level,
        progress: (xp - current) / (next - current),
        xpToNext: next - xp,
    };
};
export const masteryTitle = (level, lang = 'es') => lang === 'es'
    ? (MASTERY_TITLES_ES[Math.min(level, MASTERY_TITLES_ES.length - 1)] ?? 'Novato')
    : (MASTERY_TITLES_EN[Math.min(level, MASTERY_TITLES_EN.length - 1)] ?? 'Rookie');
export const masteryIsValidCharacter = (id) => CHARACTER_IDS.includes(id) && id in CHARACTERS;
