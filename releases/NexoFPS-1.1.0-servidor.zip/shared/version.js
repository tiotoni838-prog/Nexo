export const GAME_NAME = 'Nexo FPS';
export const GAME_VERSION = '1.1.0';
