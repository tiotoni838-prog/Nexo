import { randomUUID } from 'node:crypto';
import { loadPayPalConfig, PayPalClient, PayPalConfigError } from './paypalClient.js';
import { STORE_CATALOG, DALO_PACKS, findStoreItem } from './store.js';
export class StoreService {
    env;
    paypal = null;
    configError = null;
    purchases = new Map();
    constructor(env = process.env) {
        this.env = env;
        try {
            this.paypal = new PayPalClient(loadPayPalConfig(env));
        }
        catch (err) {
            this.configError = err instanceof PayPalConfigError ? err.message : String(err);
        }
    }
    get available() {
        return this.paypal !== null;
    }
    catalog() {
        return [...STORE_CATALOG, ...DALO_PACKS].map(({ sku, nameEs, nameEn, priceUsd, priceNx, priceDalos, currency, kind, rarity }) => ({
            sku,
            nameEs,
            nameEn,
            priceUsd: priceUsd ?? null,
            priceNx: priceNx ?? null,
            priceDalos: priceDalos ?? null,
            currency,
            kind,
            rarity,
        }));
    }
    async createPurchase(sku, baseUrl) {
        if (!this.paypal)
            throw new PayPalConfigError(this.configError ?? 'paypal-not-configured');
        const item = findStoreItem(sku);
        if (!item)
            throw new Error('sku-not-found');
        if (item.currency !== 'USD' || !item.priceUsd)
            throw new Error('sku-not-purchasable-with-usd');
        const orderId = randomUUID();
        const order = await this.paypal.createOrder({
            sku: item.sku,
            priceUsd: item.priceUsd,
            description: cosmeticDescription(item.nameEs, item.kind),
            referenceId: orderId,
            returnUrl: `${baseUrl}/api/store/return`,
            cancelUrl: `${baseUrl}/api/store/cancel`,
            idempotencyKey: orderId,
        });
        this.purchases.set(order.id, {
            orderId: order.id,
            sku,
            status: 'created',
            createdAt: Date.now(),
        });
        return { orderId: order.id, approveUrl: order.approveUrl };
    }
    async capture(token) {
        if (!this.paypal)
            throw new PayPalConfigError(this.configError ?? 'paypal-not-configured');
        const record = this.purchases.get(token);
        if (!record)
            throw new Error('order-not-found');
        const result = await this.paypal.captureOrder(token);
        record.status = result.status === 'COMPLETED' ? 'captured' : 'failed';
        return record;
    }
}
const cosmeticDescription = (name, kind) => kind === 'dalo-pack'
    ? `Nexo FPS: ${name} (moneda del juego)`
    : `Nexo FPS cosmético: ${name}`;
export const handleStoreRoutes = (req, res, url, store) => {
    if (!url.pathname.startsWith('/api/store'))
        return false;
    const json = (status, body) => {
        res.writeHead(status, { 'content-type': 'application/json' });
        res.end(JSON.stringify(body));
    };
    if (url.pathname === '/api/store/catalog' && req.method === 'GET') {
        json(200, { items: store.catalog() });
        return true;
    }
    if (url.pathname === '/api/store/purchase' && req.method === 'POST') {
        if (!store.available) {
            json(503, {
                error: 'store-not-configured',
                msg: 'Configura PAYPAL_CLIENT_ID y PAYPAL_CLIENT_SECRET como variables de entorno del servidor (nunca en el código).',
            });
            return true;
        }
        let body = '';
        req.on('data', (chunk) => {
            body += chunk;
            if (body.length > 4096)
                req.destroy();
        });
        req.on('end', () => {
            try {
                const { sku } = JSON.parse(body);
                if (!sku) {
                    json(400, { error: 'sku-required' });
                    return;
                }
                const baseUrl = `${url.protocol}//${url.host}`;
                void store
                    .createPurchase(sku, baseUrl)
                    .then((r) => json(201, r))
                    .catch((err) => json(400, { error: err.message }));
            }
            catch {
                json(400, { error: 'bad-json' });
            }
        });
        return true;
    }
    if (url.pathname === '/api/store/return' && req.method === 'GET') {
        const token = url.searchParams.get('token');
        if (!token) {
            json(400, { error: 'token-required' });
            return true;
        }
        void store
            .capture(token)
            .then((r) => {
            if (r.status === 'captured') {
                res.writeHead(302, { location: `/?comprado=${encodeURIComponent(r.sku)}` });
                res.end();
            }
            else {
                json(200, { status: r.status, sku: r.sku });
            }
        })
            .catch((err) => json(400, { error: err.message }));
        return true;
    }
    if (url.pathname === '/api/store/cancel') {
        json(200, { status: 'cancelled' });
        return true;
    }
    json(404, { error: 'not-found' });
    return true;
};
export const mountStoreRoutes = (server, store) => {
    server.on('request', (req, res) => {
        handleStoreRoutes(req, res, new URL(req.url ?? '/', 'http://localhost'), store);
    });
};
