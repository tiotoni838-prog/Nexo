export class Rng {
    state;
    constructor(seed) {
        this.state = seed >>> 0 || 0x9e3779b9;
    }
    next() {
        let x = this.state;
        x ^= x << 13;
        x ^= x >>> 17;
        x ^= x << 5;
        this.state = x >>> 0;
        return this.state / 0x100000000;
    }
    range(min, max) {
        return min + this.next() * (max - min);
    }
    int(minInclusive, maxInclusive) {
        return Math.floor(this.range(minInclusive, maxInclusive + 1));
    }
    pick(items) {
        return items[this.int(0, items.length - 1)];
    }
    chance(p) {
        return this.next() < p;
    }
}
