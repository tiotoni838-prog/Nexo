import { PROTOCOL_VERSION } from './constants.js';
export const isProtocolCompatible = (clientProtocol) => clientProtocol === PROTOCOL_VERSION;
