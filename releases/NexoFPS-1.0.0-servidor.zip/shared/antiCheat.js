export const DEFAULT_ANTI_CHEAT_CONFIG = {
    maxSpeedPerTick: 12,
    teleportThresholdPerTick: 90,
    strikeLimit: 10,
    strikeDecayMs: 10_000,
};
export class AntiCheatMonitor {
    last = new Map();
    strikes = new Map();
    config;
    constructor(config = {}) {
        this.config = { ...DEFAULT_ANTI_CHEAT_CONFIG, ...config };
    }
    validateMovement(playerId, x, y, nowMs, worldRadius) {
        const prev = this.last.get(playerId);
        this.last.set(playerId, { x, y, timeMs: nowMs });
        if (Math.hypot(x, y) > worldRadius + 50) {
            return this.penalize(playerId, nowMs, 'out-of-world');
        }
        if (!prev)
            return this.okVerdict();
        const dist = Math.hypot(x - prev.x, y - prev.y);
        if (dist > this.config.teleportThresholdPerTick) {
            return this.penalize(playerId, nowMs, 'teleport');
        }
        if (dist > this.config.maxSpeedPerTick) {
            return this.penalize(playerId, nowMs, 'speed');
        }
        return this.okVerdict();
    }
    validateFireInterval(weaponIntervalMs, lastShotMs, nowMs) {
        if (lastShotMs < 0)
            return true;
        return nowMs - lastShotMs >= weaponIntervalMs - 10;
    }
    strikeCount(playerId) {
        return this.strikes.get(playerId)?.count ?? 0;
    }
    shouldKick(playerId) {
        return this.strikeCount(playerId) >= this.config.strikeLimit;
    }
    decay(nowMs) {
        for (const [id, s] of this.strikes) {
            if (nowMs - s.lastAtMs > this.config.strikeDecayMs)
                this.strikes.delete(id);
        }
    }
    forget(playerId) {
        this.last.delete(playerId);
        this.strikes.delete(playerId);
    }
    okVerdict() {
        return { ok: true, strikes: 0, reason: 'ok' };
    }
    penalize(playerId, nowMs, reason) {
        const entry = this.strikes.get(playerId) ?? { count: 0, lastAtMs: nowMs };
        entry.count += 1;
        entry.lastAtMs = nowMs;
        this.strikes.set(playerId, entry);
        return { ok: false, strikes: entry.count, reason };
    }
}
