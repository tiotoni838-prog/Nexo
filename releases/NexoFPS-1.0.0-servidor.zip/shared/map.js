import { MAP_SIZE, WORLD_RADIUS } from './constants.js';
import { Rng } from './rng.js';
export const MAP_PRESETS = {
    'nexo-urbano': {
        nameEs: 'Nexo Urbano',
        nameEn: 'Nexo Urban',
        palette: {
            ground: '#1b2430',
            groundAlt: '#232f3d',
            obstacle: '#3a4a5e',
            obstacleTop: '#4d6178',
            sky: '#0b111a',
        },
        pois: [
            ['Puerto Nexo', 'Nexo Port'],
            ['Torres Gemelas de Cuarzo', 'Quartz Twin Towers'],
            ['Bosque de Antenas', 'Antenna Forest'],
            ['Cráter Aurora', 'Aurora Crater'],
            ['Mercado Flotante', 'Floating Market'],
            ['Refinería del Sol', 'Sun Refinery'],
            ['Jardines Colgantes', 'Hanging Gardens'],
            ['Estación Cero', 'Zero Station'],
        ],
        obstacleCount: 90,
    },
    'desierto-solar': {
        nameEs: 'Desierto Solar',
        nameEn: 'Solar Desert',
        palette: {
            ground: '#8a6b3d',
            groundAlt: '#9c7c48',
            obstacle: '#6b5230',
            obstacleTop: '#8a6b40',
            sky: '#2a1f10',
        },
        pois: [
            ['Cañón Rojo', 'Red Canyon'],
            ['Pueblo Polvo', 'Dust Town'],
            ['Ruinas del Sol', 'Sun Ruins'],
            ['Pozo Seco', 'Dry Well'],
            ['Dunas Doradas', 'Golden Dunes'],
            ['Fuerte Calavera', 'Skull Fort'],
            ['Oasis Espejo', 'Mirror Oasis'],
            ['Mina Abandonada', 'Abandoned Mine'],
        ],
        obstacleCount: 120,
    },
    'volcan-ceniza': {
        nameEs: 'Volcán Ceniza',
        nameEn: 'Ash Volcano',
        palette: {
            ground: '#2b1d1d',
            groundAlt: '#3a2626',
            obstacle: '#4a3030',
            obstacleTop: '#6b3f33',
            sky: '#160b0b',
        },
        pois: [
            ['Cráter Principal', 'Main Crater'],
            ['Coladas de Lava', 'Lava Flows'],
            ['Pueblo Ceniza', 'Ash Village'],
            ['Grietas Rugientes', 'Roaring Fissures'],
            ['Observatorio Umbral', 'Threshold Observatory'],
            ['Campo de Obsidiana', 'Obsidian Field'],
            ['Refugio Subterráneo', 'Underground Shelter'],
            ['Pico Tormenta', 'Storm Peak'],
        ],
        obstacleCount: 60,
    },
};
export const MAP_PRESET_IDS = Object.keys(MAP_PRESETS);
export const isMapPresetId = (value) => typeof value === 'string' && Object.prototype.hasOwnProperty.call(MAP_PRESETS, value);
const POI_NAMES = MAP_PRESETS['nexo-urbano'].pois;
const rectOverlapsAny = (r, rects) => rects.some((o) => r.x < o.x + o.w + 30 && r.x + r.w + 30 > o.x && r.y < o.y + o.h + 30 && r.y + r.h + 30 > o.y);
export const generateMap = (seed, presetId = 'nexo-urbano') => {
    const preset = MAP_PRESETS[presetId];
    const rng = new Rng(seed ^ hashPreset(presetId));
    const pois = [];
    const obstacles = [];
    const lootSpawns = [];
    const poiCount = 8;
    const minDistBetween = 520;
    for (let i = 0; i < poiCount; i++) {
        let center = { x: 0, y: 0 };
        let ok = false;
        for (let attempt = 0; attempt < 60 && !ok; attempt++) {
            center = {
                x: rng.range(-WORLD_RADIUS + 260, WORLD_RADIUS - 260),
                y: rng.range(-WORLD_RADIUS + 260, WORLD_RADIUS - 260),
            };
            ok = pois.every((p) => Math.hypot(p.center.x - center.x, p.center.y - center.y) > minDistBetween);
        }
        const radius = rng.range(110, 170);
        const buildings = [];
        const buildingCount = rng.int(3, 6);
        for (let b = 0; b < buildingCount; b++) {
            for (let attempt = 0; attempt < 20; attempt++) {
                const w = rng.range(60, 130);
                const h = rng.range(60, 130);
                const rect = {
                    x: center.x + rng.range(-radius, radius - w),
                    y: center.y + rng.range(-radius, radius - h),
                    w,
                    h,
                };
                if (!rectOverlapsAny(rect, buildings)) {
                    buildings.push(rect);
                    break;
                }
            }
        }
        pois.push({ nameEs: preset.pois[i][0], nameEn: preset.pois[i][1], center, radius, buildings });
        obstacles.push(...buildings);
        const spawnCount = rng.int(6, 10);
        for (let s = 0; s < spawnCount; s++) {
            lootSpawns.push({
                x: center.x + rng.range(-radius, radius),
                y: center.y + rng.range(-radius, radius),
            });
        }
    }
    for (let t = 0; t < preset.obstacleCount; t++) {
        const size = 16 + rng.next() * 22;
        const rect = {
            x: rng.range(-WORLD_RADIUS + 40, WORLD_RADIUS - 40 - size),
            y: rng.range(-WORLD_RADIUS + 40, WORLD_RADIUS - 40 - size),
            w: size,
            h: size,
        };
        if (!rectOverlapsAny(rect, obstacles)) {
            obstacles.push(rect);
            if (rng.chance(0.35))
                lootSpawns.push({ x: rect.x + size / 2, y: rect.y + size / 2 });
        }
    }
    return {
        size: MAP_SIZE,
        presetId,
        nameEs: preset.nameEs,
        nameEn: preset.nameEn,
        palette: preset.palette,
        pois,
        obstacles,
        lootSpawns,
    };
};
const hashPreset = (presetId) => {
    let h = 0x811c9dc5;
    for (let i = 0; i < presetId.length; i++) {
        h ^= presetId.charCodeAt(i);
        h = Math.imul(h, 0x01000193) >>> 0;
    }
    return h;
};
export const pointInRect = (px, py, r) => px >= r.x && px <= r.x + r.w && py >= r.y && py <= r.y + r.h;
export const circleIntersectsRect = (cx, cy, radius, r) => {
    const nx = Math.max(r.x, Math.min(cx, r.x + r.w));
    const ny = Math.max(r.y, Math.min(cy, r.y + r.h));
    const dx = cx - nx;
    const dy = cy - ny;
    return dx * dx + dy * dy <= radius * radius;
};
export const circleHitsObstacle = (cx, cy, radius, obstacles) => obstacles.some((o) => circleIntersectsRect(cx, cy, radius, o));
export const segmentHitsRect = (ax, ay, bx, by, r) => {
    if (pointInRect(ax, ay, r) || pointInRect(bx, by, r))
        return true;
    const segIntersect = (p1x, p1y, p2x, p2y, p3x, p3y, p4x, p4y) => {
        const d = (p2x - p1x) * (p4y - p3y) - (p2y - p1y) * (p4x - p3x);
        if (d === 0)
            return false;
        const t = ((p3x - p1x) * (p4y - p3y) - (p3y - p1y) * (p4x - p3x)) / d;
        const u = ((p3x - p1x) * (p2y - p1y) - (p3y - p1y) * (p2x - p1x)) / d;
        return t >= 0 && t <= 1 && u >= 0 && u <= 1;
    };
    return (segIntersect(ax, ay, bx, by, r.x, r.y, r.x + r.w, r.y) ||
        segIntersect(ax, ay, bx, by, r.x + r.w, r.y, r.x + r.w, r.y + r.h) ||
        segIntersect(ax, ay, bx, by, r.x + r.w, r.y + r.h, r.x, r.y + r.h) ||
        segIntersect(ax, ay, bx, by, r.x, r.y + r.h, r.x, r.y));
};
